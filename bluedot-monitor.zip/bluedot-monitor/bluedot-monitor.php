<?php
/**
 * Plugin Name: Bluedot Monitor
 * Plugin URI:  https://analytics.bluedotmarketing.ca/plugin/update-check
 * Description: Automated form testing and uptime monitoring for Bluedot Marketing clients.
 * Version:     1.0.9
 * Author:      Bluedot Marketing
 * Author URI:  https://bluedotmarketing.ca
 * Update URI:  https://analytics.bluedotmarketing.ca/plugin/update-check
 */

if (!defined('ABSPATH')) exit;

// ── Plugin action links ───────────────────────────────────────────────────────
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'bdm_action_links');
function bdm_action_links($links) {
    $settings_link = '<a href="' . admin_url('options-general.php?page=bdm-settings') . '">Settings</a>';
    array_unshift($links, $settings_link);
    return $links;
}

define('BDM_VERSION',     '1.0.9');
define('BDM_OPTION',      'bdm_settings');
define('BDM_WEBHOOK',     'https://analytics.bluedotmarketing.ca/api/monitor/ping');
define('BDM_WEBHOOK_LOCAL', 'http://127.0.0.1/api/monitor/ping');
define('BDM_UPDATE_URL',  'https://analytics.bluedotmarketing.ca/plugin/update-check');
define('BDM_CRON_HOOK',   'bdm_run_form_test');
define('BDM_PING_HOOK',   'bdm_send_heartbeat');

// ── Activation / Deactivation ─────────────────────────────────────────────────
register_activation_hook(__FILE__, 'bdm_activate');
register_deactivation_hook(__FILE__, 'bdm_deactivate');

function bdm_activate() {
    bdm_schedule_events();
}

function bdm_deactivate() {
    wp_clear_scheduled_hook(BDM_CRON_HOOK);
    wp_clear_scheduled_hook(BDM_PING_HOOK);
}

function bdm_schedule_events() {
    $settings  = get_option(BDM_OPTION, array());
    $frequency = isset($settings['frequency']) ? intval($settings['frequency']) : 7;

    wp_clear_scheduled_hook(BDM_CRON_HOOK);
    wp_clear_scheduled_hook(BDM_PING_HOOK);

    if (!empty($settings['client_id']) && !empty($settings['secret_key'])) {
        $interval_name = 'bdm_every_' . $frequency . '_days';
        if (!wp_next_scheduled(BDM_CRON_HOOK)) {
            wp_schedule_event(time() + 60, $interval_name, BDM_CRON_HOOK);
        }
        if (!wp_next_scheduled(BDM_PING_HOOK)) {
            wp_schedule_event(time() + 60, 'twicedaily', BDM_PING_HOOK);
        }
    }
}

// ── Custom cron intervals ─────────────────────────────────────────────────────
add_filter('cron_schedules', function($schedules) {
    foreach ([3, 5, 7] as $days) {
        $schedules['bdm_every_' . $days . '_days'] = [
            'interval' => $days * DAY_IN_SECONDS,
            'display'  => "Every {$days} days (Bluedot Monitor)"
        ];
    }
    return $schedules;
});

// ── Cron jobs ─────────────────────────────────────────────────────────────────
add_action(BDM_CRON_HOOK, 'bdm_run_form_test');
// Note: heartbeat ping removed - analytics server now pulls results directly

function bdm_send_heartbeat() {
    $settings = get_option(BDM_OPTION, array());
    if (empty($settings['client_id']) || empty($settings['secret_key'])) return;
    $body = json_encode(array(
        'clientId'  => $settings['client_id'],
        'secretKey' => $settings['secret_key'],
        'event'     => 'uptime',
        'siteUrl'   => get_site_url()
    ));
    // Try localhost first (same server - bypasses firewall)
    $resp = wp_remote_post(BDM_WEBHOOK_LOCAL, array(
        'body'      => $body,
        'headers'   => array('Content-Type' => 'application/json', 'Host' => 'analytics.bluedotmarketing.ca'),
        'timeout'   => 5,
        'blocking'  => false,
        'sslverify' => false
    ));
    if (is_wp_error($resp)) {
        wp_remote_post(BDM_WEBHOOK, array(
            'body'     => $body,
            'headers'  => array('Content-Type' => 'application/json'),
            'timeout'  => 10,
            'blocking' => false
        ));
    }
}

function bdm_run_form_test() {
    $settings = get_option(BDM_OPTION, []);
    if (empty($settings['client_id']) || empty($settings['secret_key'])) return;
    if (empty($settings['form_id'])) {
        bdm_report_result(false, 'No form ID configured');
        return;
    }

    // Get all form IDs to test
    $form_ids = isset($settings['form_ids']) ? $settings['form_ids'] : array();
    $primary  = intval(isset($settings['form_id']) ? $settings['form_id'] : 0);
    if ($primary > 0 && !in_array($primary, $form_ids)) $form_ids[] = $primary;
    if (empty($form_ids)) {
        bdm_report_result(false, 'No form ID configured', 0);
        return;
    }

    // Check Gravity Forms is active
    if (!class_exists('GFAPI')) {
        bdm_report_result(false, 'Gravity Forms not active', 0);
        return;
    }

    // Test each form
    foreach ($form_ids as $form_id) {
        bdm_test_single_form(intval($form_id), $settings);
    }
}

function bdm_test_single_form($form_id, $settings) {
    $form = GFAPI::get_form($form_id);
    if (!$form || is_wp_error($form)) {
        bdm_report_result(false, "Form ID {$form_id} not found", $form_id);
        return;
    }

    // Build submission from configured field mappings
    $field_values = [];
    $mapped_fields = isset($settings['fields']) ? $settings['fields'] : [];

    foreach ($form['fields'] as $field) {
        $field_id  = (string) $field->id;
        $field_key = 'input_' . str_replace('.', '_', $field_id);

        // Check if we have a mapped value for this field
        if (isset($mapped_fields[$field_id]) && $mapped_fields[$field_id] !== '') {
            $field_values[$field_key] = sanitize_text_field($mapped_fields[$field_id]);
        } else {
            // Auto-fill based on field type
            $type = $field->type;
            if ($type === 'email') {
                $field_values[$field_key] = 'formcheck@bluedotmarketing.ca';
            } elseif ($type === 'name') {
                // Name field has sub-fields
                $field_values['input_' . $field_id . '_3'] = 'Bluedot';
                $field_values['input_' . $field_id . '_6'] = 'Monitor';
            } elseif ($type === 'phone') {
                $field_values[$field_key] = '250-000-0000';
            } elseif ($type === 'text' || $type === 'textarea') {
                $field_values[$field_key] = 'Automated test submission from Bluedot Monitor. Please ignore.';
            } elseif ($type === 'select' || $type === 'radio') {
                // Pick first choice
                if (!empty($field->choices)) {
                    $field_values[$field_key] = $field->choices[0]['value'];
                }
            } elseif ($type === 'checkbox') {
                if (!empty($field->choices)) {
                    $field_values[$field_key . '_1'] = $field->choices[0]['value'];
                }
            }
            // Skip file upload, captcha, recaptcha, honeypot, html, page, section fields
        }
    }

    // Build entry array for direct insertion (bypasses all spam/captcha checks)
    $entry = array(
        'form_id'       => $form_id,
        'date_created'  => current_time('mysql', 1),
        'source_url'    => get_site_url() . ' [Bluedot Monitor Test]',
        'user_agent'    => 'BluedotMonitor/1.0',
        'created_by'    => 0,
        'status'        => 'active',
        'is_starred'    => 0,
        'is_read'       => 0,
        'ip'            => '127.0.0.1',
    );

    // Add field values to entry
    foreach ($field_values as $key => $val) {
        // Convert input_X_Y format to X.Y for entry
        $field_key = str_replace('input_', '', $key);
        $field_key = str_replace('_', '.', $field_key);
        // But only if it looks like a field ID (numeric with optional .sub)
        if (preg_match('/^[\d.]+$/', $field_key)) {
            $entry[$field_key] = $val;
        }
    }

    // Insert entry directly - no spam check, no captcha, no honeypot
    try {
        $entry_id = GFAPI::add_entry($entry);
    } catch (Exception $e) {
        bdm_report_result(false, 'GFAPI exception: ' . $e->getMessage(), $form_id);
        return;
    }

    if (is_wp_error($entry_id)) {
        bdm_report_result(false, 'GFAPI error: ' . $entry_id->get_error_message(), $form_id);
        return;
    }

    // Fire GF submission notifications (sends confirmation emails etc.)
    $entry = GFAPI::get_entry($entry_id);
    if (!is_wp_error($entry)) {
        GFAPI::send_notifications($form, $entry, 'form_submission');
    }

    bdm_report_result(true, "Form #{$form_id} submitted successfully. Entry ID: " . $entry_id, $form_id);
}

function bdm_bypass_captcha_validation($result, $value, $form, $field) {
    $captcha_types = array('captcha', 'recaptcha', 'honeypot');
    if (in_array(strtolower($field->type), $captcha_types)) {
        return array('is_valid' => true, 'message' => '');
    }
    // Also bypass "Your Company Name" spam check (field type text with JS check)
    if (isset($result['is_valid']) && !$result['is_valid'] && strpos($result['message'], 'Spamming') !== false) {
        return array('is_valid' => true, 'message' => '');
    }
    return $result;
}

function bdm_restore_filters() {
    remove_filter('gform_spam_emails',            '__return_false', 99);
    remove_filter('gform_enable_spam_prevention', '__return_false', 99);
    remove_filter('gform_field_validation',       'bdm_bypass_captcha_validation', 99);
}

function bdm_report_result($success, $message, $form_id = 0) {
    $settings = get_option(BDM_OPTION, array());
    $payload  = array(
        'clientId'  => $settings['client_id'],
        'secretKey' => $settings['secret_key'],
        'event'     => 'form_test',
        'formId'    => $form_id ? $form_id : (isset($settings['form_id']) ? $settings['form_id'] : ''),
        'success'   => $success,
        'message'   => $message,
        'siteUrl'   => get_site_url()
    );
    $body    = json_encode($payload);
    $headers = array('Content-Type' => 'application/json', 'Host' => 'analytics.bluedotmarketing.ca');
    // Try localhost first (same server - bypasses firewall)
    $response = wp_remote_post(BDM_WEBHOOK_LOCAL, array(
        'body'      => $body,
        'headers'   => $headers,
        'timeout'   => 10,
        'sslverify' => false
    ));
    // Fall back to external URL
    if (is_wp_error($response)) {
        $response = wp_remote_post(BDM_WEBHOOK, array(
            'body'    => $body,
            'headers' => array('Content-Type' => 'application/json'),
            'timeout' => 15
        ));
    }
    // Log result
    $log = get_option('bdm_test_log', []);
    array_unshift($log, [
        'success'   => $success,
        'message'   => $message,
        'at'        => current_time('mysql'),
        'sent'      => !is_wp_error($response)
    ]);
    update_option('bdm_test_log', array_slice($log, 0, 20));
}

// ── Auto-update checker ───────────────────────────────────────────────────────
add_filter('plugins_api',                  'bdm_plugin_info',       20, 3);
add_filter('site_transient_update_plugins','bdm_check_for_update',  10, 1);
add_filter('upgrader_process_complete',    'bdm_after_update',      10, 2);

function bdm_get_remote_info() {
    $cached = get_transient('bdm_remote_info');
    if (false !== $cached) return $cached;
    $response = wp_remote_get(BDM_UPDATE_URL, array(
        'timeout'   => 15,
        'sslverify' => false,
        'headers'   => array('Accept' => 'application/json')
    ));
    if (is_wp_error($response)) return false;
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body);
    if (!$data || empty($data->version)) return false;
    set_transient('bdm_remote_info', $data, 6 * HOUR_IN_SECONDS);
    return $data;
}

function bdm_check_for_update($transient) {
    if (!is_object($transient)) $transient = new stdClass();
    if (!isset($transient->checked)) $transient->checked = array();
    if (!isset($transient->response)) $transient->response = array();

    $plugin_file = plugin_basename(__FILE__);
    $remote      = bdm_get_remote_info();

    if ($remote && isset($remote->version) && version_compare(BDM_VERSION, $remote->version, '<')) {
        $update = new stdClass();
        $update->id          = 'bluedot-monitor';
        $update->slug        = 'bluedot-monitor';
        $update->plugin      = $plugin_file;
        $update->new_version = $remote->version;
        $update->url         = BDM_UPDATE_URL;
        $update->package     = isset($remote->download_url) ? $remote->download_url : '';
        $update->icons       = array();
        $update->banners     = array();
        $update->requires    = isset($remote->requires) ? $remote->requires : '5.8';
        $update->tested      = isset($remote->tested)   ? $remote->tested   : '6.5';
        $transient->response[$plugin_file] = $update;
    }
    return $transient;
}

function bdm_plugin_info($res, $action, $args) {
    if ('plugin_information' !== $action) return $res;
    if (!isset($args->slug) || 'bluedot-monitor' !== $args->slug) return $res;
    $remote = bdm_get_remote_info();
    if (!$remote) return $res;
    $info                = new stdClass();
    $info->name          = 'Bluedot Monitor';
    $info->slug          = 'bluedot-monitor';
    $info->version       = $remote->version;
    $info->author        = 'Bluedot Marketing';
    $info->homepage      = BDM_UPDATE_URL;
    $info->download_link = isset($remote->download_url) ? $remote->download_url : '';
    $info->requires      = isset($remote->requires) ? $remote->requires : '5.8';
    $info->tested        = isset($remote->tested)   ? $remote->tested   : '6.5';
    $info->last_updated  = date('Y-m-d');
    $info->sections      = array(
        'description' => 'Automated Gravity Forms testing and uptime monitoring for Bluedot Marketing clients.',
        'changelog'   => isset($remote->changelog) ? $remote->changelog : ''
    );
    return $info;
}

function bdm_after_update($upgrader, $options) {
    if ('update' === $options['action'] && 'plugin' === $options['type']) {
        delete_transient('bdm_remote_info');
    }
}

// REST endpoint to clear update cache (called from Monitor Dashboard)
add_action('rest_api_init', function() {
    register_rest_route('bdm/v1', '/clear-cache', array(
        'methods'             => 'POST',
        'callback'            => 'bdm_rest_clear_cache',
        'permission_callback' => 'bdm_rest_auth'
    ));
    register_rest_route('bdm/v1', '/run-test', array(
        'methods'             => 'POST',
        'callback'            => 'bdm_rest_run_test',
        'permission_callback' => 'bdm_rest_auth'
    ));
    register_rest_route('bdm/v1', '/entry-counts', array(
        'methods'             => 'GET',
        'callback'            => 'bdm_rest_entry_counts',
        'permission_callback' => 'bdm_rest_auth'
    ));
});

function bdm_rest_auth($request) {
    $settings   = get_option(BDM_OPTION, array());
    $secret     = isset($settings['secret_key']) ? $settings['secret_key'] : '';
    $auth_header = $request->get_header('X-BDM-Key');
    return !empty($secret) && $auth_header === $secret;
}

function bdm_rest_clear_cache() {
    delete_transient('bdm_remote_info');
    delete_site_transient('update_plugins');
    return rest_ensure_response(array('ok' => true, 'message' => 'Cache cleared. Check Dashboard > Updates.'));
}

function bdm_rest_entry_counts() {
    $settings = get_option(BDM_OPTION, array());
    $form_id  = intval(isset($settings['form_id']) ? $settings['form_id'] : 0);

    if (!$form_id || !class_exists('GFAPI')) {
        return rest_ensure_response(array('ok' => false, 'current_month' => 0, 'previous_month' => 0));
    }

    // Current month date range
    $now          = current_time('timestamp');
    $curr_start   = date('Y-m-01 00:00:00', $now);
    $curr_end     = date('Y-m-t 23:59:59', $now);

    // Previous month date range
    $prev_ts      = strtotime('first day of last month', $now);
    $prev_start   = date('Y-m-01 00:00:00', $prev_ts);
    $prev_end     = date('Y-m-t 23:59:59', $prev_ts);

    // Search criteria — exclude test entries (created_by = 0 is our test marker)
    // We count entries where created_by != 0 OR source_url does not contain [Bluedot Monitor]
    $curr_count = bdm_count_real_entries($form_id, $curr_start, $curr_end);
    $prev_count = bdm_count_real_entries($form_id, $prev_start, $prev_end);

    return rest_ensure_response(array(
        'ok'             => true,
        'form_id'        => $form_id,
        'current_month'  => $curr_count,
        'previous_month' => $prev_count,
        'current_label'  => date('F Y', $now),
        'previous_label' => date('F Y', $prev_ts),
    ));
}

function bdm_count_real_entries($form_id, $start_date, $end_date) {
    $search = array(
        'start_date' => $start_date,
        'end_date'   => $end_date,
        'status'     => 'active',
    );
    $entries = GFAPI::get_entries($form_id, $search, null, array('offset' => 0, 'page_size' => 500));
    if (!is_array($entries)) return 0;

    $count = 0;
    foreach ($entries as $entry) {
        // Skip our automated test entries — they have source_url containing [Bluedot Monitor]
        // and created_by = 0
        $source = isset($entry['source_url']) ? $entry['source_url'] : '';
        $creator = isset($entry['created_by']) ? intval($entry['created_by']) : -1;
        if ($creator === 0 && strpos($source, 'Bluedot Monitor') !== false) continue;
        $count++;
    }
    return $count;
}

function bdm_rest_run_test() {
    // Run all configured form tests and return results
    $settings = get_option(BDM_OPTION, array());
    $form_ids = isset($settings['form_ids']) ? $settings['form_ids'] : array();
    $primary  = intval(isset($settings['form_id']) ? $settings['form_id'] : 0);
    if ($primary > 0 && !in_array($primary, $form_ids)) $form_ids[] = $primary;

    if (empty($form_ids) || !class_exists('GFAPI')) {
        return rest_ensure_response(array(
            'ok'     => false,
            'result' => array('success' => false, 'message' => empty($form_ids) ? 'No form ID configured' : 'Gravity Forms not active')
        ));
    }

    $results = array();
    foreach ($form_ids as $form_id) {
        $form_id = intval($form_id);
        $form    = GFAPI::get_form($form_id);
        if (!$form || is_wp_error($form)) {
            $results[] = array('success' => false, 'message' => "Form #{$form_id} not found", 'formId' => $form_id);
            continue;
        }
        // Build field values
        $mapped       = isset($settings['fields']) ? $settings['fields'] : array();
        $skip_types   = array('captcha','recaptcha','honeypot','html','section','page','fileupload','signature');
        $field_values = array();
        foreach ($form['fields'] as $field) {
            if (in_array($field->type, $skip_types)) continue;
            $fid      = (string) $field->id;
            $fkey     = str_replace('.', '_', $fid);
            $type     = $field->type;
            if (isset($mapped[$fid]) && $mapped[$fid] !== '') {
                $field_values['input_' . $fkey] = sanitize_text_field($mapped[$fid]);
            } elseif ($type === 'email') {
                $field_values['input_' . $fkey] = 'formcheck@bluedotmarketing.ca';
            } elseif ($type === 'name') {
                $field_values['input_' . $fid . '_3'] = 'Bluedot';
                $field_values['input_' . $fid . '_6'] = 'Monitor';
            } elseif ($type === 'phone') {
                $field_values['input_' . $fkey] = '250-000-0000';
            } elseif (in_array($type, array('text','textarea'))) {
                $field_values['input_' . $fkey] = 'Automated test submission from Bluedot Monitor. Please ignore.';
            } elseif (in_array($type, array('select','radio')) && !empty($field->choices)) {
                $field_values['input_' . $fkey] = $field->choices[0]['value'];
            } elseif ($type === 'checkbox' && !empty($field->choices)) {
                $field_values['input_' . $fkey . '_1'] = $field->choices[0]['value'];
            }
        }
        // Insert via add_entry (bypasses spam/captcha)
        $entry = array(
            'form_id'      => $form_id,
            'date_created' => current_time('mysql', 1),
            'source_url'   => get_site_url() . ' [Bluedot Monitor]',
            'user_agent'   => 'BluedotMonitor/1.0',
            'created_by'   => 0,
            'status'       => 'active',
            'ip'           => '127.0.0.1',
        );
        foreach ($field_values as $key => $val) {
            $fkey2 = str_replace('input_', '', $key);
            $fkey2 = str_replace('_', '.', $fkey2);
            if (preg_match('/^[\d.]+$/', $fkey2)) $entry[$fkey2] = $val;
        }
        try {
            $entry_id = GFAPI::add_entry($entry);
        } catch (Exception $e) {
            $results[] = array('success' => false, 'message' => 'Exception: ' . $e->getMessage(), 'formId' => $form_id);
            continue;
        }
        if (is_wp_error($entry_id)) {
            $results[] = array('success' => false, 'message' => $entry_id->get_error_message(), 'formId' => $form_id);
        } else {
            // Fire notifications
            $saved = GFAPI::get_entry($entry_id);
            if (!is_wp_error($saved)) GFAPI::send_notifications($form, $saved, 'form_submission');
            $results[] = array('success' => true, 'message' => "Form #{$form_id} submitted. Entry ID: {$entry_id}", 'formId' => $form_id);
        }
    }

    // Log results locally
    $log = get_option('bdm_test_log', array());
    foreach ($results as $r) {
        array_unshift($log, array('success' => $r['success'], 'message' => $r['message'], 'at' => current_time('mysql'), 'sent' => true));
    }
    update_option('bdm_test_log', array_slice($log, 0, 20));

    // Return first result (or worst result if multiple)
    $failed = array_filter($results, function($r) { return !$r['success']; });
    $main   = !empty($failed) ? array_values($failed)[0] : $results[0];
    return rest_ensure_response(array('ok' => true, 'result' => $main, 'all_results' => $results));
}

// ── Admin settings page ───────────────────────────────────────────────────────
add_action('admin_menu', function() {
    add_options_page('Bluedot Monitor', 'Bluedot Monitor', 'manage_options', 'bdm-settings', 'bdm_settings_page');
});

add_action('admin_init', function() {
    register_setting('bdm_settings_group', BDM_OPTION, 'bdm_sanitize_settings');
});

function bdm_sanitize_settings($input) {
    if (!is_array($input)) return get_option(BDM_OPTION, array());
    $clean = array();
    $clean['client_id']  = sanitize_text_field(isset($input['client_id'])  ? $input['client_id']  : '');
    $clean['secret_key'] = sanitize_text_field(isset($input['secret_key']) ? $input['secret_key'] : '');
    // Support multiple form IDs
    $clean['form_id']  = intval(isset($input['form_id'])  ? $input['form_id']  : 0);
    $clean['form_ids'] = array();
    if (!empty($input['form_ids']) && is_array($input['form_ids'])) {
        foreach ($input['form_ids'] as $fid) {
            $fid = intval($fid);
            if ($fid > 0) $clean['form_ids'][] = $fid;
        }
    }
    // Always include primary form_id in form_ids
    if ($clean['form_id'] > 0 && !in_array($clean['form_id'], $clean['form_ids'])) {
        $clean['form_ids'][] = $clean['form_id'];
    }
    $clean['frequency']  = intval(isset($input['frequency']) ? $input['frequency'] : 7);
    $clean['fields']     = array();
    if (!empty($input['fields']) && is_array($input['fields'])) {
        foreach ($input['fields'] as $fid => $val) {
            $clean['fields'][sanitize_text_field($fid)] = sanitize_text_field($val);
        }
    }
    // Schedule after option is saved via shutdown hook to avoid recursion
    add_action('shutdown', 'bdm_schedule_events');
    return $clean;
}

function bdm_settings_page() {
    $settings = get_option(BDM_OPTION, []);
    $form_id  = intval($settings['form_id'] ?? 0);
    $log      = get_option('bdm_test_log', []);
    $forms    = class_exists('GFAPI') ? GFAPI::get_forms() : [];
    $fields   = ($form_id && class_exists('GFAPI')) ? GFAPI::get_form($form_id)['fields'] ?? [] : [];
    $mapped   = $settings['fields'] ?? [];
    ?>
    <div class="wrap" style="max-width:800px">
        <h1 style="display:flex;align-items:center;gap:10px">
            <span style="display:inline-block;width:12px;height:12px;border-radius:50%;background:<?php echo !empty($settings['client_id']) ? '#10c97a' : '#ef4444'; ?>"></span>
            Bluedot Monitor <small style="font-size:13px;color:#666;font-weight:400">v<?php echo BDM_VERSION; ?></small>
        </h1>

        <?php if (isset($_GET['settings-updated'])) echo '<div class="notice notice-success"><p>Settings saved.</p></div>'; ?>

        <form method="post" action="options.php">
            <?php settings_fields('bdm_settings_group'); ?>

            <table class="form-table">
                <tr><th>Client ID</th><td>
                    <input type="text" name="<?php echo BDM_OPTION; ?>[client_id]" value="<?php echo esc_attr($settings['client_id'] ?? ''); ?>" class="regular-text" placeholder="From Bluedot Analytics admin" />
                    <p class="description">Found in Bluedot Analytics → Admin → Clients → Monitor tab.</p>
                </td></tr>

                <tr><th>Secret Key</th><td>
                    <input type="text" name="<?php echo BDM_OPTION; ?>[secret_key]" value="<?php echo esc_attr($settings['secret_key'] ?? ''); ?>" class="regular-text" placeholder="Paste from Bluedot Analytics" />
                    <p class="description">Auto-generated in Bluedot Analytics. Keep this private.</p>
                </td></tr>

                <tr><th>Gravity Forms to Test</th><td>
                    <p style="margin-bottom:8px"><strong>Primary Form</strong></p>
                    <select name="<?php echo BDM_OPTION; ?>[form_id]">
                        <option value="">— Select a form —</option>
                        <?php foreach ($forms as $f): ?>
                            <option value="<?php echo $f['id']; ?>" <?php selected($form_id, $f['id']); ?>>
                                <?php echo esc_html($f['title']); ?> (ID: <?php echo $f['id']; ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </td></tr>

                <tr><th>Additional Forms</th><td>
                    <p style="margin-bottom:8px;color:#666;font-size:13px">Add more form IDs to test multiple forms on this site.</p>
                    <div id="bdm-extra-forms">
                    <?php
                    $extra_ids  = isset($settings['form_ids']) ? $settings['form_ids'] : array();
                    $primary_id = intval(isset($settings['form_id']) ? $settings['form_id'] : 0);
                    $extra_ids  = array_filter($extra_ids, function($id) use ($primary_id) { return intval($id) !== $primary_id; });
                    foreach ($extra_ids as $extra_fid): ?>
                    <div style="display:flex;gap:8px;margin-bottom:6px;align-items:center">
                        <select name="<?php echo BDM_OPTION; ?>[form_ids][]" style="flex:1">
                            <option value="">— Select form —</option>
                            <?php foreach ($forms as $f): ?>
                                <option value="<?php echo $f['id']; ?>" <?php selected($extra_fid, $f['id']); ?>>
                                    <?php echo esc_html($f['title']); ?> (ID: <?php echo $f['id']; ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <?php endforeach; ?>
                    <div style="display:flex;gap:8px;margin-bottom:6px;align-items:center">
                        <select name="<?php echo BDM_OPTION; ?>[form_ids][]" style="flex:1">
                            <option value="">— Add another form (optional) —</option>
                            <?php foreach ($forms as $f): ?>
                                <option value="<?php echo $f['id']; ?>">
                                    <?php echo esc_html($f['title']); ?> (ID: <?php echo $f['id']; ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    </div>
                </td></tr>

                <tr><th>Test Frequency</th><td>
                    <select name="<?php echo BDM_OPTION; ?>[frequency]">
                        <option value="3" <?php selected($settings['frequency'] ?? 7, 3); ?>>Every 3 days</option>
                        <option value="5" <?php selected($settings['frequency'] ?? 7, 5); ?>>Every 5 days</option>
                        <option value="7" <?php selected($settings['frequency'] ?? 7, 7); ?>>Every 7 days</option>
                    </select>
                </td></tr>
            </table>

            <?php if ($fields): ?>
            <h2>Form Field Mapping</h2>
            <p>Map each form field to a test value. Leave blank to use smart defaults. Email fields always use <strong>formcheck@bluedotmarketing.ca</strong>.</p>
            <table class="form-table">
                <?php
                $skip_types = array('captcha', 'recaptcha', 'honeypot', 'html', 'section', 'page', 'fileupload', 'signature');
                foreach ($fields as $field):
                    if (in_array($field->type, $skip_types)) continue;
                    $fid   = (string) $field->id;
                    $label = $field->label ?: "Field {$fid}";
                    $type  = $field->type;
                    $is_email = $type === 'email';
                    $val   = $is_email ? 'formcheck@bluedotmarketing.ca' : ($mapped[$fid] ?? '');
                ?>
                <tr>
                    <th><?php echo esc_html($label); ?> <small style="color:#666;font-weight:400">(<?php echo $type; ?>, ID: <?php echo $fid; ?>)</small></th>
                    <td>
                        <input type="<?php echo $is_email ? 'email' : 'text'; ?>"
                               name="<?php echo BDM_OPTION; ?>[fields][<?php echo $fid; ?>]"
                               value="<?php echo esc_attr($val); ?>"
                               class="regular-text"
                               <?php echo $is_email ? 'readonly style="background:#f0f0f0"' : ''; ?>
                               placeholder="<?php echo $is_email ? '' : 'Auto-fill'; ?>" />
                        <?php if ($is_email): ?>
                            <span style="color:#666;font-size:12px">Always uses test email</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
            <?php endif; ?>

            <?php submit_button('Save Settings'); ?>
        </form>

        <hr>
        <h2>Plugin Updates</h2>
        <p>Current version: <strong>v<?php echo BDM_VERSION; ?></strong></p>
        <?php
        // Force fresh check if requested
        if (isset($_GET['bdm_update_check']) && wp_verify_nonce($_GET['_wpnonce'], 'bdm_update_check')) { delete_transient('bdm_remote_info'); delete_site_transient('update_plugins'); }
        $remote = bdm_get_remote_info();
        if ($remote && version_compare(BDM_VERSION, $remote->version, '<')): ?>
            <div style="background:#fff3cd;border:1px solid #ffc107;border-radius:6px;padding:12px 16px;margin:10px 0;display:flex;align-items:center;justify-content:space-between">
                <span><strong>Update available: v<?php echo esc_html($remote->version); ?></strong></span>
                <a href="<?php echo admin_url('update-core.php'); ?>" class="button button-primary">Update Now</a>
            </div>
        <?php elseif ($remote): ?>
            <div style="background:#d4edda;border:1px solid #28a745;border-radius:6px;padding:10px 16px;margin:10px 0;color:#155724">
                ✓ Plugin is up to date (latest: v<?php echo esc_html($remote->version); ?>)
            </div>
        <?php elseif (isset($_GET['bdm_update_check'])): ?>
            <div style="background:#f8d7da;border:1px solid #dc3545;border-radius:6px;padding:10px 16px;margin:10px 0;color:#721c24">
                ✗ Could not reach update server. Check your internet connection.
            </div>
        <?php endif; ?>
        <?php
        $check_url = wp_nonce_url(
            admin_url('options-general.php?page=bdm-settings&bdm_update_check=1'),
            'bdm_update_check'
        );
        ?>
        <a href="<?php echo esc_url($check_url); ?>" class="button button-secondary">Check for Updates</a>

        <hr>
        <h2>Manual Test</h2>
        <p>Run a form test right now without waiting for the schedule.</p>
        <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
            <input type="hidden" name="action" value="bdm_run_test_now" />
            <?php wp_nonce_field('bdm_run_test_now'); ?>
            <?php submit_button('Run Test Now', 'secondary'); ?>
        </form>

        <?php if ($log): ?>
        <hr>
        <h2>Recent Test Results</h2>
        <table class="widefat striped" style="max-width:700px">
            <thead><tr><th>Status</th><th>Message</th><th>Date</th></tr></thead>
            <tbody>
            <?php foreach (array_slice($log, 0, 10) as $entry): ?>
                <tr>
                    <td><?php echo $entry['success'] ? '<span style="color:#10c97a">✓ Pass</span>' : '<span style="color:#ef4444">✗ Fail</span>'; ?></td>
                    <td><?php echo esc_html($entry['message']); ?></td>
                    <td><?php echo esc_html($entry['at']); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
    <?php
}

// Manual test trigger
add_action('admin_post_bdm_run_test_now', function() {
    check_admin_referer('bdm_run_test_now');
    if (!current_user_can('manage_options')) wp_die('Unauthorized');
    bdm_run_form_test();
    wp_redirect(admin_url('options-general.php?page=bdm-settings&settings-updated=1'));
    exit;
});
